from my_robot_interfaces.srv._next_goal import NextGoal  # noqa: F401
