// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACES__SRV__NEXT_GOAL_HPP_
#define MY_ROBOT_INTERFACES__SRV__NEXT_GOAL_HPP_

#include "my_robot_interfaces/srv/detail/next_goal__struct.hpp"
#include "my_robot_interfaces/srv/detail/next_goal__builder.hpp"
#include "my_robot_interfaces/srv/detail/next_goal__traits.hpp"

#endif  // MY_ROBOT_INTERFACES__SRV__NEXT_GOAL_HPP_
